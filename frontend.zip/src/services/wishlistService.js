/**
 * 📁 src/services/wishlistService.js
 *
 * Thin API layer — mirrors cartService pattern.
 */

import api from '@/lib/api';

export const wishlistService = {
  /** GET /api/wishlist — full populated wishlist */
  getWishlist: () => api.get('/wishlist'),

  /** POST /api/wishlist/items — add product { productId } */
  addItem: (productId) => api.post('/wishlist/items', { productId: String(productId) }),

  /** DELETE /api/wishlist/items/:productId — remove single */
  removeItem: (productId) => api.delete(`/wishlist/items/${String(productId)}`),

  /** DELETE /api/wishlist — clear entire wishlist */
  clearWishlist: () => api.delete('/wishlist'),

  /** GET /api/wishlist/check/:productId — quick boolean check */
  checkItem: (productId) => api.get(`/wishlist/check/${String(productId)}`),

  /** POST /api/wishlist/move-to-cart — move all items to cart */
  moveAllToCart: () => api.post('/wishlist/move-to-cart'),
};
