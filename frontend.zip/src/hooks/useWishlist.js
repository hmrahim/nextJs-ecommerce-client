'use client';
/**
 * 📁 src/hooks/useWishlist.js
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useSession } from 'next-auth/react';
import toast from 'react-hot-toast';
import { wishlistService } from '@/services/wishlistService';
import { CART_KEY } from '@/hooks/useCart';

export const WISHLIST_KEY = ['wishlist'];

const normalizeWishlist = (raw) => {
  const items = raw?.items || [];
  return {
    items,
    itemCount: raw?.itemCount ?? items.length,
    updatedAt: raw?.updatedAt,
  };
};

/* ── GET ─────────────────────────────────────────────────────── */
export function useWishlist() {
  const { data: session } = useSession();

  return useQuery({
    queryKey: WISHLIST_KEY,
    queryFn: async () => {
      const { data } = await wishlistService.getWishlist();
      return normalizeWishlist(data?.data);
    },
    enabled: !!session,
    staleTime: 60 * 1000,
  });
}

/* ── Derived: Set<string> for O(1) heart check ───────────────── */
export function useWishlistIds() {
  const { data } = useWishlist();
  return new Set(
    (data?.items || []).map((i) => String(i.product?._id || i.product))
  );
}

/* ── TOGGLE — FIX: read from cache inside mutationFn ─────────── */
export function useToggleWishlist() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (product) => {
      const pid = String(product._id || product.id);

      // ✅ FIX: Read current cache HERE (not from stale closure)
      const current = qc.getQueryData(WISHLIST_KEY);
      const alreadyIn = (current?.items || []).some(
        (i) => String(i.product?._id || i.product) === pid
      );

      if (alreadyIn) {
        return wishlistService.removeItem(pid).then((res) => ({ ...res, _action: 'removed' }));
      }
      return wishlistService.addItem(pid).then((res) => ({ ...res, _action: 'added' }));
    },

    /* Optimistic update */
    onMutate: async (product) => {
      await qc.cancelQueries({ queryKey: WISHLIST_KEY });
      const prev = qc.getQueryData(WISHLIST_KEY);
      const pid = String(product._id || product.id);

      const current = prev || { items: [], itemCount: 0 };
      const alreadyIn = current.items.some(
        (i) => String(i.product?._id || i.product) === pid
      );

      const nextItems = alreadyIn
        ? current.items.filter((i) => String(i.product?._id || i.product) !== pid)
        : [
            ...current.items,
            {
              product: {
                _id: pid,
                name: product.name,
                slug: product.slug,
                images: product.images,
                price: product.price,
                comparePrice: product.comparePrice,
                avgRating: product.avgRating,
                reviewCount: product.reviewCount,
                brand: product.brand,
                inStock: product.inStock,
                isActive: true,
              },
              addedAt: new Date().toISOString(),
            },
          ];

      qc.setQueryData(WISHLIST_KEY, {
        ...current,
        items: nextItems,
        itemCount: nextItems.length,
      });

      // ✅ FIX: Store action intent in context, NOT toast here
      return { prev, action: alreadyIn ? 'removed' : 'added' };
    },

    onSuccess: (_data, _product, ctx) => {
      // ✅ Toast ONLY on confirmed success
      toast.success(ctx?.action === 'removed' ? 'Removed from wishlist' : 'Added to wishlist');
    },

    onError: (_err, _product, ctx) => {
      // Roll back optimistic update
      if (ctx?.prev) qc.setQueryData(WISHLIST_KEY, ctx.prev);
      toast.error('Could not update wishlist. Please try again.');
    },

    onSettled: () => {
      qc.invalidateQueries({ queryKey: WISHLIST_KEY });
    },
  });
}

/* ── CLEAR ───────────────────────────────────────────────────── */
export function useClearWishlist() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: () => wishlistService.clearWishlist(),
    onSuccess: () => {
      qc.setQueryData(WISHLIST_KEY, { items: [], itemCount: 0 });
      toast.success('Wishlist cleared');
    },
    onError: () => toast.error('Could not clear wishlist'),
  });
}

/* ── MOVE ALL TO CART ────────────────────────────────────────── */
export function useMoveAllToCart() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: () => wishlistService.moveAllToCart(),
    onSuccess: ({ data }) => {
      qc.setQueryData(WISHLIST_KEY, { items: [], itemCount: 0 });
      qc.invalidateQueries({ queryKey: CART_KEY });
      toast.success(data?.message || 'All items moved to cart');
    },
    onError: (err) =>
      toast.error(err?.response?.data?.message || 'Could not move items to cart'),
  });
}