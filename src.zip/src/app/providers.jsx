'use client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { SessionProvider } from 'next-auth/react';
import { useState } from 'react';
import { Toaster } from 'react-hot-toast';

export default function Providers({ children, session }) {
  const [queryClient] = useState(
    () => new QueryClient({
      defaultOptions: {
        queries: {
          staleTime:            60 * 1000,       // 1 minute — refetch will be closed
          gcTime:               5 * 60 * 1000,   // 5 minute memory In cache will be
          retry:                1,
          refetchOnWindowFocus: false,            // ✅ Tab switch In refetch closed
          refetchOnReconnect:   false,            // ✅ Network reconnect In refetch closed
        },
      },
    })
  );

  return (
    <SessionProvider session={session}>
      <QueryClientProvider client={queryClient}>
        {children}
        <Toaster position="top-right" />
        <ReactQueryDevtools initialIsOpen={false} />
      </QueryClientProvider>
    </SessionProvider>
  );
}
