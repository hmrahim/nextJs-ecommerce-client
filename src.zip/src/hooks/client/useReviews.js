// 📁 PATH: src/hooks/client/useReviews.js
//
// ─── CLIENT-SIDE REVIEW HOOKS ────────────────────────────────────────────────
// Covers:
//   1. useProductReviews   — paginated approved reviews for a product
//   2. useSubmitReview     — create a new review (mutation)
//   3. useUpdateReview     — edit own review (mutation)
//   4. useDeleteReview     — delete own review (mutation)
// ─────────────────────────────────────────────────────────────────────────────

'use client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { reviewService } from '@/services/reviewService';
import toast from 'react-hot-toast';

/* ── Query Key Factory ───────────────────────────────────────────────── */
export const reviewKeys = {
  all:        ()                     => ['client-reviews'],
  byProduct:  (productId, filters)   => ['client-reviews', 'product', productId, filters],
};

/* ══════════════════════════════════════════════════════════════════════
   1. useProductReviews
      Fetches paginated, approved reviews for a single product.

   filters shape:
   {
     page?:   number          // default 1
     limit?:  number          // default 10
     sort?:   'newest' | 'oldest' | 'highest' | 'lowest' | 'helpful'
     rating?: 1 | 2 | 3 | 4 | 5   // filter by exact star
   }

   returns: {
     data: {
       results:     Review[]
       total:       number
       page:        number
       pages:       number
       stats: {
         avgRating:    number
         totalReviews: number
         distribution: { 5: n, 4: n, 3: n, 2: n, 1: n }
       }
     }
     isLoading, isFetching, isError
   }
══════════════════════════════════════════════════════════════════════ */
export function useProductReviews(productId, filters = {}) {
  const { page = 1, limit = 10, sort = 'newest', rating } = filters;

  return useQuery({
    queryKey: reviewKeys.byProduct(productId, { page, limit, sort, rating }),
    queryFn: async () => {
      const params = { page, limit, sort };
      if (rating) params.rating = rating;
      const res = await reviewService.getByProduct(productId, params);
      return res.data;
      // shape: { success, total, page, pages, limit, stats, results }
    },
    enabled:          !!productId,
    staleTime:        1000 * 60 * 2,
    keepPreviousData: true,
  });
}

/* ══════════════════════════════════════════════════════════════════════
   2. useSubmitReview
      POST /products/:productId/reviews

   usage:
     const { mutate, isPending } = useSubmitReview(productId);
     mutate({ rating, title, body, images, orderId });

   On success:
     - Invalidates the review list for this product
     - Shows success toast
   On error:
     - Shows error toast (409 = already reviewed, etc.)
══════════════════════════════════════════════════════════════════════ */
export function useSubmitReview(productId) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data) => reviewService.create(productId, data),

    onSuccess: () => {
      toast.success('Review submitted! It will appear after moderation.');
      // Invalidate so the list refreshes (the new review will show once approved)
      queryClient.invalidateQueries({ queryKey: reviewKeys.byProduct(productId) });
    },

    onError: (err) => {
      const msg = err?.response?.data?.message ?? 'Failed to submit review';
      toast.error(msg);
    },
  });
}

/* ══════════════════════════════════════════════════════════════════════
   3. useUpdateReview
      PUT /reviews/:reviewId

   usage:
     const { mutate, isPending } = useUpdateReview(productId);
     mutate({ reviewId, data: { rating, title, body, images } });
══════════════════════════════════════════════════════════════════════ */
export function useUpdateReview(productId) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ reviewId, data }) => reviewService.update(reviewId, data),

    onSuccess: () => {
      toast.success('Review updated and pending re-moderation.');
      queryClient.invalidateQueries({ queryKey: reviewKeys.byProduct(productId) });
    },

    onError: (err) => {
      const msg = err?.response?.data?.message ?? 'Failed to update review';
      toast.error(msg);
    },
  });
}

/* ══════════════════════════════════════════════════════════════════════
   4. useDeleteReview
      DELETE /reviews/:reviewId

   usage:
     const { mutate, isPending } = useDeleteReview(productId);
     mutate(reviewId);
══════════════════════════════════════════════════════════════════════ */
export function useDeleteReview(productId) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (reviewId) => reviewService.delete(reviewId),

    onSuccess: () => {
      toast.success('Review deleted.');
      queryClient.invalidateQueries({ queryKey: reviewKeys.byProduct(productId) });
    },

    onError: (err) => {
      const msg = err?.response?.data?.message ?? 'Failed to delete review';
      toast.error(msg);
    },
  });
}