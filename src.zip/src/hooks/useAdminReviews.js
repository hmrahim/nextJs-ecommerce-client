// 📁 PATH: src/hooks/useAdminReviews.js
'use client';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { reviewService } from '@/services/reviewService';
import toast from 'react-hot-toast';

/* ── Query Key Factory ───────────────────────────────────────────── */
export const adminReviewKeys = {
  all:    ()        => ['admin-reviews'],
  list:   (filters) => ['admin-reviews', 'list', filters],
  detail: (id)      => ['admin-reviews', 'detail', id],
  stats:  ()        => ['admin-reviews', 'stats'],
};

/* ── Cache helpers ───────────────────────────────────────────────── */

/** একটি review-এর isApproved field cache-এ patch করো */
function patchApproval(queryClient, id, isApproved) {
  queryClient.setQueriesData({ queryKey: adminReviewKeys.all() }, (old) => {
    if (!old?.results) return old;
    return {
      ...old,
      results: old.results.map((r) =>
        r._id === id ? { ...r, isApproved } : r
      ),
    };
  });
}

/** একাধিক review cache থেকে সরাও */
function removeFromCache(queryClient, ids) {
  queryClient.setQueriesData({ queryKey: adminReviewKeys.all() }, (old) => {
    if (!old?.results) return old;
    const updated = old.results.filter((r) => !ids.includes(r._id));
    return {
      ...old,
      results: updated,
      total: Math.max(0, (old.total ?? 0) - (old.results.length - updated.length)),
    };
  });
}

/* ══════════════════════════════════════════════════════════════════
   1. useAdminReviews — paginated list with filters
      filters shape: { search, status, rating, sort, page, limit }
══════════════════════════════════════════════════════════════════ */
export function useAdminReviews(filters = {}) {
  const { page = 1, limit = 15, search, status, rating, sort = 'createdAt:desc' } = filters;

  // Convert 'createdAt:desc' → backend param format
  const [sortField, sortDir] = sort.split(':');
  const sortParam = sortDir === 'asc' ? sortField : `-${sortField}`;

  return useQuery({
    queryKey: adminReviewKeys.list({ page, limit, search, status, rating, sort }),
    queryFn: async () => {
      const res = await reviewService.adminGetAll({
        page,
        limit,
        sort:     sortParam,
        status:   status   || undefined,
        rating:   rating   || undefined,
        search:   search   || undefined,
      });
      return res.data;
      // shape: { success, total, page, pages, limit, results: Review[] }
    },
    staleTime:        1000 * 60 * 2,
    keepPreviousData: true,
  });
}

/* ══════════════════════════════════════════════════════════════════
   2. useAdminReviewStats — stats cards
══════════════════════════════════════════════════════════════════ */
export function useAdminReviewStats() {
  return useQuery({
    queryKey: adminReviewKeys.stats(),
    queryFn: async () => {
      const res = await reviewService.adminGetStats();
      return res.data.data;
      // shape: { total, approved, pending, rejected, verified, avgRating, distribution }
    },
    staleTime: 1000 * 60 * 3,
  });
}

/* ══════════════════════════════════════════════════════════════════
   3. useAdminReviewById — single review detail (for modal)
══════════════════════════════════════════════════════════════════ */
export function useAdminReviewById(id) {
  return useQuery({
    queryKey: adminReviewKeys.detail(id),
    queryFn: async () => {
      const res = await reviewService.adminGetById(id);
      return res.data.data;
    },
    enabled:   !!id,
    staleTime: 1000 * 60 * 2,
  });
}

/* ══════════════════════════════════════════════════════════════════
   4. useApproveReview
══════════════════════════════════════════════════════════════════ */
export function useApproveReview() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id) => reviewService.adminApprove(id),

    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: adminReviewKeys.all() });
      const snapshot = queryClient.getQueriesData({ queryKey: adminReviewKeys.all() });
      patchApproval(queryClient, id, true);
      return { snapshot };
    },

    onSuccess: (_, id) => {
      toast.success('Review approved');
      // Refresh stats
      queryClient.invalidateQueries({ queryKey: adminReviewKeys.stats() });
      // Refresh detail cache if open
      queryClient.invalidateQueries({ queryKey: adminReviewKeys.detail(id) });
    },

    onError: (_err, _id, ctx) => {
      ctx?.snapshot?.forEach(([key, data]) => queryClient.setQueryData(key, data));
      toast.error('Failed to approve review');
    },

    onSettled: () => queryClient.invalidateQueries({ queryKey: adminReviewKeys.list({}) }),
  });
}

/* ══════════════════════════════════════════════════════════════════
   5. useRejectReview
══════════════════════════════════════════════════════════════════ */
export function useRejectReview() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id) => reviewService.adminReject(id),

    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: adminReviewKeys.all() });
      const snapshot = queryClient.getQueriesData({ queryKey: adminReviewKeys.all() });
      patchApproval(queryClient, id, false);
      return { snapshot };
    },

    onSuccess: (_, id) => {
      toast.success('Review rejected');
      queryClient.invalidateQueries({ queryKey: adminReviewKeys.stats() });
      queryClient.invalidateQueries({ queryKey: adminReviewKeys.detail(id) });
    },

    onError: (_err, _id, ctx) => {
      ctx?.snapshot?.forEach(([key, data]) => queryClient.setQueryData(key, data));
      toast.error('Failed to reject review');
    },

    onSettled: () => queryClient.invalidateQueries({ queryKey: adminReviewKeys.list({}) }),
  });
}

/* ══════════════════════════════════════════════════════════════════
   6. useDeleteReview (admin)
══════════════════════════════════════════════════════════════════ */
export function useAdminDeleteReview() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id) => reviewService.adminDelete(id),

    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: adminReviewKeys.all() });
      const snapshot = queryClient.getQueriesData({ queryKey: adminReviewKeys.all() });
      removeFromCache(queryClient, [id]);
      return { snapshot };
    },

    onSuccess: () => {
      toast.success('Review deleted');
      queryClient.invalidateQueries({ queryKey: adminReviewKeys.stats() });
    },

    onError: (_err, _id, ctx) => {
      ctx?.snapshot?.forEach(([key, data]) => queryClient.setQueryData(key, data));
      toast.error('Failed to delete review');
    },

    onSettled: () => queryClient.invalidateQueries({ queryKey: adminReviewKeys.list({}) }),
  });
}

/* ══════════════════════════════════════════════════════════════════
   7. useAdminReplyReview
══════════════════════════════════════════════════════════════════ */
export function useAdminReplyReview() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, reply }) => reviewService.adminReply(id, reply),

    onSuccess: (_, { id }) => {
      toast.success('Reply posted');
      queryClient.invalidateQueries({ queryKey: adminReviewKeys.detail(id) });
      // Patch reply into list cache too
      queryClient.setQueriesData({ queryKey: adminReviewKeys.all() }, (old) => {
        if (!old?.results) return old;
        return {
          ...old,
          results: old.results.map((r) =>
            r._id === id
              ? { ...r, adminReply: _.data?.data?.adminReply ?? r.adminReply }
              : r
          ),
        };
      });
    },

    onError: () => toast.error('Failed to post reply'),
  });
}

/* ══════════════════════════════════════════════════════════════════
   8. useAdminBulkReviewAction
      action: 'approve' | 'reject' | 'delete'
══════════════════════════════════════════════════════════════════ */
export function useAdminBulkReviewAction() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ ids, action }) => reviewService.adminBulkAction(ids, action),

    onMutate: async ({ ids, action }) => {
      await queryClient.cancelQueries({ queryKey: adminReviewKeys.all() });
      const snapshot = queryClient.getQueriesData({ queryKey: adminReviewKeys.all() });

      if (action === 'delete') {
        removeFromCache(queryClient, ids);
      } else {
        const isApproved = action === 'approve';
        queryClient.setQueriesData({ queryKey: adminReviewKeys.all() }, (old) => {
          if (!old?.results) return old;
          return {
            ...old,
            results: old.results.map((r) =>
              ids.includes(r._id) ? { ...r, isApproved } : r
            ),
          };
        });
      }

      return { snapshot };
    },

    onSuccess: (_, { ids, action }) => {
      toast.success(`${ids.length} review${ids.length > 1 ? 's' : ''} ${action}d`);
      queryClient.invalidateQueries({ queryKey: adminReviewKeys.stats() });
    },

    onError: (_err, _vars, ctx) => {
      ctx?.snapshot?.forEach(([key, data]) => queryClient.setQueryData(key, data));
      toast.error('Bulk action failed');
    },

    onSettled: () => queryClient.invalidateQueries({ queryKey: adminReviewKeys.list({}) }),
  });
}